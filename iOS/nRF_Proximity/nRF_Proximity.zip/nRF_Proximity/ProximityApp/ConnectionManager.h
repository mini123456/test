//
//  ConnectionManager.h
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

#import "ProximityTag.h"
#import "ProximityTagStorage.h"

@protocol ConnectionManagerDelegate <ProximityTagDelegate>
- (void) isBluetoothEnabled:(bool) enabled;
- (void) didDiscoverTag:(ProximityTag*) tag;

@end

@interface ConnectionManager : NSObject <CBCentralManagerDelegate>
@property id<ConnectionManagerDelegate> delegate;

+ (ConnectionManager*) sharedInstance;

- (void) startScanForTags;
- (void) stopScanForTags;
- (void) retrieveKnownPeripherals;
- (void) disconnectTag:(ProximityTag*) tag;


@end
