//
//  ConnectionManager.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "ConnectionManager.h"

@implementation ConnectionManager {
    CBCentralManager *cm;
}
@synthesize delegate = _delegate;

static ConnectionManager *sharedConnectionManager;

+ (ConnectionManager*) sharedInstance
{
    if (sharedConnectionManager == nil)
    {
        sharedConnectionManager = [[ConnectionManager alloc] initWithDelegate:nil];
    }
    return sharedConnectionManager;
}

- (ConnectionManager*) initWithDelegate:(id<ConnectionManagerDelegate>) delegate
{
    if (self = [super init])
    {
        _delegate = delegate;
        
        cm = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return self;
}

- (void) retrieveKnownPeripherals
{
    NSMutableArray *uuidArray = [[NSMutableArray alloc] init];
    for (ProximityTag* tag in [[ProximityTagStorage sharedInstance] tagsWithoutPeripheral]) 
    {
        if([tag peripheralCFUUIDRef])
            [uuidArray addObject:(id) [tag peripheralCFUUIDRef]];
    }
    NSLog(@"Trying to retrieve %d peripherals: %@", [uuidArray count], uuidArray);
    [cm retrievePeripherals:uuidArray];
}

- (void) startScanForTags
{
    NSDictionary* scanOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:CBCentralManagerScanOptionAllowDuplicatesKey];
    NSArray* serviceArray = [NSArray arrayWithObjects:ProximityTag.linkLossServiceUUID, ProximityTag.findMeServiceUUID, nil];

    // Make sure we start scan from scratch
    [cm stopScan];
    
    [cm scanForPeripheralsWithServices:serviceArray options:scanOptions];
}

- (void) stopScanForTags
{
    [cm stopScan];
}

- (void) connectToTag:(ProximityTag*) tag
{
    NSDictionary* connectOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey];
    
    NSLog(@"Connecting to tag %@...", [tag name]);
    [cm connectPeripheral:[tag peripheral] options:connectOptions];
}

- (void) disconnectTag:(ProximityTag*) tag
{
    if (tag.peripheral)
    {
        NSLog(@"Disconnecting from tag %@...", [tag name]);
        [cm cancelPeripheralConnection:[tag peripheral]];
    }
    else 
    {
        NSLog(@"Not disconnecting from tag %@, since it appears to not be connected.", [tag name]);
    }
}

- (void) centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSLog(@"Central manager did update state.");
    if ([central state] == CBCentralManagerStatePoweredOn)
    {
        [_delegate isBluetoothEnabled:YES];        
        
        [self retrieveKnownPeripherals];
    }
    else 
    {
        [_delegate isBluetoothEnabled:NO];
    }
    
}

- (void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    // Abort if this device is already in the list
    if([[ProximityTagStorage sharedInstance] tagWithUUID:[peripheral UUID]])
        return;
    
    
    ProximityTag *tag = [[ProximityTag alloc] init];
    tag.peripheral = peripheral;
    tag.rssiLevel = [RSSI floatValue];
    
    [[ProximityTagStorage sharedInstance] insertTag:tag];
    
    [self connectToTag:tag];
    [self.delegate didDiscoverTag:tag];
    
}

- (void) centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals
{
    NSLog(@"Did retrieve %d peripherals.", [peripherals count]);
    
    for (CBPeripheral* p in peripherals)
    {
        ProximityTag* tag = [[ProximityTagStorage sharedInstance] tagWithUUID:[p UUID]];
        tag.peripheral = p;
        tag.delegate = _delegate;
        
        [self connectToTag:tag];
    }
}

- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"Did connect peripheral %@", [peripheral name]);
    ProximityTag *tag = [[ProximityTagStorage sharedInstance] tagWithPeripheral:peripheral];
    if (!tag) {
        NSLog(@"Couldn't find a tag for this peripheral.");
        return;
    }
    // Cannot save before we have connected, since the UUID might be empty
    [[ProximityTagStorage sharedInstance] saveTags];

    [tag didConnect];
}

- (void) centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    ProximityTag *tag = [[ProximityTagStorage sharedInstance] tagWithPeripheral:peripheral];
    if (!tag) {
        NSLog(@"Disconnected %@, but couldn't find a tag for this peripheral. Will not reconnect.", [peripheral name]);
        return;
    }
    [_delegate didUpdateData:tag];
    [tag didDisconnect];
    
    NSLog(@"Did disconnect peripheral, %@ with error %@. Trying to reconnect...", [peripheral name], error);
    
    [self connectToTag:tag];
}


@end
