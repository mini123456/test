//
//  LastSeenViewController.h
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#import "ProximityTag.h"
#import "LastSeenViewController.h"

@interface LastSeenViewController : UIViewController <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *lastSeenMapView;
@property ProximityTag* activeTag;

@end
