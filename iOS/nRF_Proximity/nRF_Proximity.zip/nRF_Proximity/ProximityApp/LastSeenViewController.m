//
//  LastSeenViewController.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "LastSeenViewController.h"

@interface LastSeenViewController ()

@end

@implementation LastSeenViewController
@synthesize lastSeenMapView;
@synthesize activeTag;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self.lastSeenMapView setRegion:MKCoordinateRegionMakeWithDistance([self.activeTag.lastSeenLocation coordinate], 1000.0, 1000.0) animated:NO];
    
    MKPointAnnotation* lastSeenPoint = [[MKPointAnnotation alloc] init];
    lastSeenPoint.coordinate = self.activeTag.lastSeenLocation.coordinate;
    [self.lastSeenMapView addAnnotation:lastSeenPoint];

}

- (void)viewDidUnload
{
    [self setLastSeenMapView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
