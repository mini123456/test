//
//  MasterViewController.h
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

#import "ProximityTag.h"
#import "ProximityTagStorage.h"
#import "ProximityTagViewController.h"
#import "ConnectionManager.h"


@interface ListViewController : UIViewController <ConnectionManagerDelegate, UITableViewDelegate>
{
    CBCentralManager *cm;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *addTagActivityIndicator;
@property (weak, nonatomic) IBOutlet UILabel *addTagHelpLabel;
@property (nonatomic) bool isScanning;
@property (nonatomic) NSTimer* helpTextTimer;

- (IBAction) addTagButtonPressed:(id)sender;

@end
