//
//  MasterViewController.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "ListViewController.h"

@implementation ListViewController
@synthesize tableView;
@synthesize addTagActivityIndicator;
@synthesize addTagHelpLabel;
@synthesize isScanning;
@synthesize helpTextTimer = _helpTextTimer;

- (void) awakeFromNib
{
    [super awakeFromNib];
}

- (void) viewDidLoad
{
    [super viewDidLoad];

    // Since we are not attaching to a UITableView, but a UIView, we must connect this ourselves
    self.tableView.dataSource =  [ProximityTagStorage sharedInstance];
    self.tableView.delegate = self;

    [[ConnectionManager sharedInstance] setDelegate:self];
}

- (void) viewWillAppear:(BOOL)animated
{
    for (ProximityTag* tag in [[ProximityTagStorage sharedInstance] tags]) 
    {
        tag.delegate = self;
    }
    [tableView reloadData];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [self stopScanForTags];
}

- (void) viewDidUnload
{
    tableView = nil;
    [self setTableView:nil];
    [self setAddTagActivityIndicator:nil];
    [self setAddTagHelpLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction) addTagButtonPressed:(id)sender
{
    if(!isScanning) 
    {
        [self startScanForTags];
    } 
    else 
    {
        [self stopScanForTags];
    }
    
}

- (void) startScanForTags
{
    [addTagActivityIndicator startAnimating];
    
    NSLog(@"Starting scan for new tags...");
    [[ConnectionManager sharedInstance] startScanForTags];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(addTagButtonPressed:)];

    self.helpTextTimer = [NSTimer timerWithTimeInterval:10.0 target:self selector:@selector(helpTextTimeout) userInfo:nil repeats:NO];
    [[NSRunLoop currentRunLoop] addTimer:self.helpTextTimer forMode:NSRunLoopCommonModes];
    
    //[self.addTagHelpLabel setHidden:NO];
    isScanning = YES;
}

- (void) helpTextTimeout
{
    self.addTagHelpLabel.hidden = NO;
}

- (void) didDiscoverTag:(ProximityTag*) tag
{
    tag.delegate = self;
    
    if ([self.helpTextTimer isValid])
    {
        [self.helpTextTimer invalidate];
    }
}

- (void) stopScanForTags
{
    [addTagActivityIndicator stopAnimating];
    [self.helpTextTimer invalidate];

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addTagButtonPressed:)];

    NSLog(@"Stopping scan for new tags.");
    
    self.addTagHelpLabel.hidden = YES;

    [[ConnectionManager sharedInstance] stopScanForTags];
    isScanning = NO;
}

- (void) didUpdateData:(ProximityTag*)tag
{
    [tableView reloadData];
}

- (void) didFailToConnect:(id)tag
{
    UIAlertView *dialog = [[UIAlertView alloc] initWithTitle:@"Failed to connect" message:[NSString stringWithFormat:@"The app couldn't connect to %@. \n\nThis usually indicates a previous bond. Go to the settings and clear it before you try again.", [tag name]] delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [dialog show];
    [self stopScanForTags];
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showDetail"]) 
    {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        
        ProximityTag *tag = [[ProximityTagStorage sharedInstance] tagAtIndex:indexPath.row];
        [[segue destinationViewController] setProximityTag:tag];
    } 
}

- (void) isBluetoothEnabled:(bool)enabled
{
    [self.navigationItem.rightBarButtonItem setEnabled:enabled];
}

@end
