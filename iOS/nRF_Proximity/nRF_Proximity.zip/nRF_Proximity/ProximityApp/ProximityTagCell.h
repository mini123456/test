//
//  ProximityTagCell.h
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProximityTagCell : UITableViewCell
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *connectionActivityIndicator;
@property (nonatomic, strong) IBOutlet UIImageView *connectionImage;
@property (nonatomic, strong) IBOutlet UILabel *nameLabel;
@end
