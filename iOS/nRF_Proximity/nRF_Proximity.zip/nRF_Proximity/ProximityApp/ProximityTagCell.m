//
//  ProximityTagCell.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "ProximityTagCell.h"

@implementation ProximityTagCell
@synthesize connectionActivityIndicator = _connectionActivityIndicator;
@synthesize connectionImage = _connectionImage;
@synthesize nameLabel = _nameLabel;
@end
