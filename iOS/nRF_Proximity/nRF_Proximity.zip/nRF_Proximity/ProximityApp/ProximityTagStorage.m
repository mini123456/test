//
//  ProximityTagStorage.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "ProximityTagStorage.h"
#import "ProximityTagCell.h"

@implementation ProximityTagStorage
@synthesize tags = _tags;

static ProximityTagStorage* sharedProximityTagStorage = nil;

+ (ProximityTagStorage*) sharedInstance 
{
    if (sharedProximityTagStorage == nil) {
        sharedProximityTagStorage = [[ProximityTagStorage alloc] init];
    }
    return sharedProximityTagStorage;
}

- (id) init
{
    if(self = [super init])
    {
        // Initialize array to store tags
        _tags = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void) insertTag:(ProximityTag*) tag
{
    if(![self isTagInList:tag])
    {
        [_tags addObject:tag];
    }
}

- (void) removeTag:(ProximityTag*) tag
{
    [_tags removeObject:tag];
}

- (bool) isTagInList:(ProximityTag*) tag
{
    return [_tags containsObject:tag];
}

- (bool) isPeripheralInList:(CBPeripheral*) peripheral
{
    for(ProximityTag* tag in _tags) 
    {
        if(tag.peripheral == peripheral)
        {
            return YES;
        }
    }
    return NO;
}

- (ProximityTag*) tagAtIndex:(NSUInteger) index
{
    return (ProximityTag*) [_tags objectAtIndex:index];
}

- (ProximityTag*) tagWithPeripheral:(CBPeripheral*) peripheral
{
    for (ProximityTag* tag in _tags)
    {
        if ([tag.peripheral isEqual:peripheral])
        {
            return tag;
        }
    }
    return nil;
}

- (ProximityTag*) tagWithUUID:(CFUUIDRef) UUIDRef
{
    for (ProximityTag* tag in _tags)
    {
        if (tag.peripheralCFUUIDRef == UUIDRef)
        {
            return tag;
        }
    }
    return nil;
}

- (NSMutableArray*) tagsWithoutPeripheral
{
    NSMutableArray *a = [NSMutableArray arrayWithArray:_tags];
    [a filterUsingPredicate:[NSPredicate predicateWithFormat:@"_peripheral == nil"]];
    return a;
}

- (NSMutableArray*) tagsWithUUID
{
    NSMutableArray *a = [NSMutableArray array];
    for (ProximityTag* tag in _tags)
    {
        if (tag.peripheral.UUID)
        {
            [a addObject:tag];
        }
    }
    return a;
}

- (void) saveTags
{
    NSMutableArray *tagsWithUUID = self.tagsWithUUID;
    
    NSLog(@"Saving %d tags...", [tagsWithUUID count]);
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:[tagsWithUUID count] forKey:@"ProximityAppTagCount"];
    
    for (NSUInteger i = 0; i < [tagsWithUUID count]; i++)
    {
        NSData *encodedTag = [NSKeyedArchiver archivedDataWithRootObject:[tagsWithUUID objectAtIndex:i]];
        [defaults setObject:encodedTag forKey:[NSString stringWithFormat:@"ProximityAppTag%d", i]];
    }
}

- (void) loadTags
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    for (NSUInteger i = 0; i < [defaults integerForKey:@"ProximityAppTagCount"]; i++) 
    {
        NSData* encodedTag = [defaults objectForKey:[NSString stringWithFormat:@"ProximityAppTag%d", i]];
        
        [self insertTag:(ProximityTag*) [NSKeyedUnarchiver unarchiveObjectWithData:encodedTag]];
    }
    NSLog(@"Did load %d tags.", [_tags count]);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _tags.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ProximityTagCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProximityTagCell"];
    ProximityTag *tag = [_tags objectAtIndex:[indexPath row]];
    cell.nameLabel.text = [tag name];
    
    if (tag.isConnected && !tag.isBonded)
    {
        [cell.connectionImage setHidden:YES];
        [cell.connectionActivityIndicator startAnimating];
    }
    else
    {
        [cell.connectionActivityIndicator stopAnimating];
        [cell.connectionImage setHidden:NO];
        [cell.connectionImage setImage:[UIImage imageNamed:tag.connectionImageNameBasedOnRSSI]];
        
    }
    
    return cell;
}
@end
