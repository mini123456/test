//
//  DetailViewController.h
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#import "ProximityTag.h"
#import "ConnectionManager.h"
#import "LastSeenViewController.h"

@interface ProximityTagViewController : UIViewController <UIAlertViewDelegate, ProximityTagDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UISegmentedControl *linkLossAlertLevelOnTagControl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *linkLossAlertLevelOnPhoneControl;
@property (weak, nonatomic) IBOutlet UISwitch *extremeSecuritySwitch;
@property (weak, nonatomic) IBOutlet UISlider *rssiThresholdSlider;
@property (weak, nonatomic) IBOutlet UILabel *batteryLabel;
@property (weak, nonatomic) IBOutlet UISwitch *locationTrackingSwitch;
@property (weak, nonatomic) IBOutlet UIImageView *connectionImage;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *connectionActivityIndicator;
@property (weak, nonatomic) IBOutlet UIButton *findTagButton;

@property (nonatomic) ProximityTag *proximityTag;
@property (nonatomic) BOOL isAlarmActive;

- (IBAction) nameChanged:(id)sender;
- (IBAction) linkLossAlertLevelOnTagChanged:(id)sender;
- (IBAction)linkLossAlertLevelOnPhoneChanged:(id)sender;
- (IBAction) rssiThresholdChanged:(id)sender;
- (IBAction) findTagPressed:(id)sender;
- (IBAction) forgetTagPressed:(id)sender;
- (IBAction) locationTrackingSwitchChanged:(id)sender;
- (IBAction) extremeSecuritySwitchChanged:(id)sender;

@end
