//
//  DetailViewController.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//

#import "ProximityTagViewController.h"

@implementation ProximityTagViewController
@synthesize proximityTag = _proximityTag;

@synthesize nameTextField = _nameTextField;
@synthesize linkLossAlertLevelOnTagControl = _remoteAlertLevelControl;
@synthesize linkLossAlertLevelOnPhoneControl = _linkLossAlertLevelOnPhoneControl;
@synthesize extremeSecuritySwitch = _extremeSecuritySwitch;
@synthesize rssiThresholdSlider = _RSSIThresholdSlider;
@synthesize batteryLabel = _batteryLabel;
@synthesize locationTrackingSwitch = _locationTrackingSwitch;
@synthesize connectionImage = _connectionImage;
@synthesize connectionActivityIndicator = _connectionActivityIndicator;

@synthesize isAlarmActive = _isAlarmActive;

#pragma mark - Managing the detail item
- (void) viewDidLoad
{
    [super viewDidLoad];
	    
    // Default segmented control is huge. Reduce its font and size.
    NSDictionary *textAttributes = [NSDictionary dictionaryWithObject:[UIFont boldSystemFontOfSize:12.0] forKey:UITextAttributeFont];
    [[self linkLossAlertLevelOnTagControl] setTitleTextAttributes:textAttributes forState:UIControlStateNormal];
    [[self linkLossAlertLevelOnPhoneControl] setTitleTextAttributes:textAttributes forState:UIControlStateNormal];
    
    [[self linkLossAlertLevelOnTagControl] setFrame:CGRectMake([[self linkLossAlertLevelOnTagControl] frame].origin.x, [[self linkLossAlertLevelOnTagControl] frame].origin.y, [[self linkLossAlertLevelOnTagControl] frame].size.width, 32)];
    [[self linkLossAlertLevelOnPhoneControl] setFrame:CGRectMake([[self linkLossAlertLevelOnPhoneControl] frame].origin.x, [[self linkLossAlertLevelOnPhoneControl] frame].origin.y, [[self linkLossAlertLevelOnPhoneControl] frame].size.width, 32)];
    
    self.isAlarmActive = false;
    
    [self updateView];
}

- (void) viewDidUnload
{
    [self setNameTextField:nil];
    [self setLinkLossAlertLevelOnTagControl:nil];
    [self setRssiThresholdSlider:nil];
    [self setBatteryLabel:nil];
    [self setLocationTrackingSwitch:nil];
    [self setConnectionActivityIndicator:nil];
    [self setConnectionImage:nil];
    [self setExtremeSecuritySwitch:nil];
    [self setLinkLossAlertLevelOnPhoneControl:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) setProximityTag:(ProximityTag *)proximityTag
{
    if (proximityTag != _proximityTag)
    {
        _proximityTag = proximityTag;
        _proximityTag.delegate = self;
        
        NSLog(@"New proximity tag set, %@ with delegate %@. Self: %@, new tag: %@. RSSI threshold %f and link loss alert %d", _proximityTag, _proximityTag.delegate, self, proximityTag, _proximityTag.rssiThreshold, _proximityTag.linkLossAlertLevelOnTag);
        
        [self updateView];
    }
}

- (IBAction) nameChanged:(id)sender {
    self.proximityTag.name = [[self nameTextField] text];
    
    // Make on-screen-keyboard disappear
    [sender resignFirstResponder];
}

- (IBAction) linkLossAlertLevelOnTagChanged:(id)sender {
    NSInteger value = [[self linkLossAlertLevelOnTagControl] selectedSegmentIndex];
    if(value == 0)
        self.proximityTag.linkLossAlertLevelOnTag = PROXIMITY_TAG_ALERT_LEVEL_NONE;
    else if (value == 1)
        self.proximityTag.linkLossAlertLevelOnTag = PROXIMITY_TAG_ALERT_LEVEL_MILD;
    else
        self.proximityTag.linkLossAlertLevelOnTag = PROXIMITY_TAG_ALERT_LEVEL_HIGH;
}

- (IBAction)linkLossAlertLevelOnPhoneChanged:(id)sender {
    NSInteger value = [[self linkLossAlertLevelOnPhoneControl] selectedSegmentIndex];
    if(value == 0)
        self.proximityTag.linkLossAlertLevelOnPhone = PROXIMITY_TAG_ALERT_LEVEL_NONE;
    else if (value == 1)
        self.proximityTag.linkLossAlertLevelOnPhone = PROXIMITY_TAG_ALERT_LEVEL_MILD;
    else
        self.proximityTag.linkLossAlertLevelOnPhone = PROXIMITY_TAG_ALERT_LEVEL_HIGH;

}


- (IBAction) rssiThresholdChanged:(id)sender {
    NSLog(@"New RSSI threshold value set to %f", [[self rssiThresholdSlider] value]);
    self.proximityTag.rssiThreshold = [[self rssiThresholdSlider] value];
}

- (IBAction) findTagPressed:(id)sender {
    if (![self.proximityTag isConnected] && [self.proximityTag lastSeenLocation] != nil) 
    {
        [self performSegueWithIdentifier:@"showMap" sender:nil];
    }
    else  if (![self.proximityTag isConnected]) 
    {
        UIAlertView* question = [[UIAlertView alloc] initWithTitle:@"No stored position" 
                                                           message:[NSString stringWithFormat:@"%@ isn't currently connected, and there is no last location stored. Unfortunately, we can therefore not find it. ", [self.proximityTag name]]
                                                          delegate:self 
                                                 cancelButtonTitle:@"OK"
                                                 otherButtonTitles:nil];
        [question show];
    }
    else
    {
        if (self.isAlarmActive)
        {
            [self muteAlarmOnTag];
        }
        else
        {
            [self setAlarmOnTag];
        }
    }
}

- (void) setAlarmOnTag
{
    BOOL status = [self.proximityTag findTag:PROXIMITY_TAG_ALERT_LEVEL_HIGH];
    if(!status)
    {
        NSLog(@"Couldn't find tag.");
        return;
    }
    self.isAlarmActive = YES;

    [self.findTagButton setTitle:@"Silence tag" forState:UIControlStateNormal];
}

- (void) muteAlarmOnTag
{
    self.isAlarmActive = NO;
    
    [self.findTagButton setTitle:@"Find tag" forState:UIControlStateNormal];
    
    if(![self.proximityTag findTag:PROXIMITY_TAG_ALERT_LEVEL_NONE])
    {
        NSLog(@"Couldn't find tag.");
    }
}

- (IBAction) locationTrackingSwitchChanged:(id)sender
{
    
    if (self.locationTrackingSwitch.on && ![CLLocationManager locationServicesEnabled])
    {
        UIAlertView *dialog = [[UIAlertView alloc] initWithTitle:@"Location Services disabled" message:@"You need to enable Location Services in the settings to use this feature. " delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [self.locationTrackingSwitch setOn:NO];
        [dialog show];
    }
    else 
    {
        [self.proximityTag setLocationTrackingIsEnabled:self.locationTrackingSwitch.on];
    }
    
}

- (IBAction) extremeSecuritySwitchChanged:(id)sender {
    [self.proximityTag setRangeMonitoringIsEnabled:self.extremeSecuritySwitch.on];
    [self.rssiThresholdSlider setEnabled:self.extremeSecuritySwitch.on];
}

- (IBAction) forgetTagPressed:(id)sender {
    UIAlertView* question = [[UIAlertView alloc] initWithTitle:@"Forget tag" 
                                                       message:[NSString stringWithFormat:@"Do you really want to remove the %@ tag?", [self.proximityTag name]]
                                                      delegate:self 
                                             cancelButtonTitle:@"Keep tag" 
                                             otherButtonTitles:@"Forget tag", nil];
    [question show];
}

- (void) alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1) {
        [[ProximityTagStorage sharedInstance] removeTag:self.proximityTag];
        [[ConnectionManager sharedInstance] disconnectTag:self.proximityTag];
        
        [[self navigationController] popViewControllerAnimated:YES];
    }
}


- (void) updateView
{
    // Update the user interface for the detail item.
    if (self.proximityTag) {
        [[self extremeSecuritySwitch] setOn:self.proximityTag.rangeMonitoringIsEnabled];
        [[self rssiThresholdSlider] setEnabled:self.proximityTag.rangeMonitoringIsEnabled];        
        [[self rssiThresholdSlider] setValue:self.proximityTag.rssiThreshold];

        [[self nameTextField] setText:self.proximityTag.name];
        
        [[self linkLossAlertLevelOnTagControl] setSelectedSegmentIndex:self.proximityTag.linkLossAlertLevelOnTag];
        [[self linkLossAlertLevelOnPhoneControl] setSelectedSegmentIndex:self.proximityTag.linkLossAlertLevelOnPhone];
        
        [self.locationTrackingSwitch setOn:self.proximityTag.locationTrackingIsEnabled];
        
        [self didUpdateData:self.proximityTag];
    }
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showMap"]) {
        LastSeenViewController *vc = [segue destinationViewController];
        [vc setActiveTag:self.proximityTag];
    }
}

- (void) didUpdateData:(id)tag
{
    // This shouldn't happen.
    if (![tag isEqual:self.proximityTag])
    {
        NSLog(@"Did update data for an unknown tag.");
        return;
    }
    
    [self.connectionImage setImage:[UIImage imageNamed:[tag connectionImageNameBasedOnRSSI]]];
    
    if ([self.proximityTag batteryLevel])
    {
        self.batteryLabel.text = [NSString stringWithFormat:@"%d %%", [self.proximityTag batteryLevel]];
    } 
    else 
    {
        self.batteryLabel.text = @"n/a";
    }
    
    if (self.proximityTag.isConnected && !self.proximityTag.isBonded)
    {
        [self.connectionImage setHidden:YES];
        [self.connectionActivityIndicator startAnimating];
    }
    else if ((self.proximityTag.isConnected && self.proximityTag.isBonded) ||
             !self.proximityTag.isConnected)
    {
        [self.connectionImage setHidden:NO];
        [self.connectionActivityIndicator stopAnimating];
    }
}


@end
