//
//  SharedUI.m
//  ProximityApp
//
//  Copyright (c) 2012 Nordic Semiconductor. All rights reserved.
//
//

#import "SharedUI.h"

@implementation SharedUI
+ (void) showFailedConnectDialog:(ProximityTag*) tag
{
    UIAlertView *dialog = [[UIAlertView alloc] initWithTitle:@"Failed to connect" message:[NSString stringWithFormat:@"The app couldn't connect to %@. \n\nThis usually indicates a previous bond. Go to the settings and clear it before you try again.", tag.name] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [dialog show];
}

+ (void) showOutOfRangeDialog:(ProximityTagAlertLevel) alertLevel forTag:(ProximityTag*) tag
{
    if (alertLevel != PROXIMITY_TAG_ALERT_LEVEL_NONE)
    {
        UILocalNotification *alarm = [[UILocalNotification alloc] init];
        alarm.alertBody = [NSString stringWithFormat:@"%@ has moved out of range.", tag.name];
        alarm.alertAction = @"OK";
        
        if (alertLevel == PROXIMITY_TAG_ALERT_LEVEL_HIGH)
        {
            alarm.soundName = @"alarm-sound.wav";
        }
        else
        {
            alarm.soundName = UILocalNotificationDefaultSoundName;
        }
        [[UIApplication sharedApplication] presentLocalNotificationNow:alarm];
    }
}

+ (void) showFindPhoneDialog:(ProximityTagAlertLevel) alertLevel forTag:(ProximityTag*) tag
{
    UILocalNotification *alarm = [[UILocalNotification alloc] init];
    alarm.alertBody = [NSString stringWithFormat:@"%@ wants to find your phone.", tag.name];
    alarm.alertAction = @"OK";
    
    [[UIApplication sharedApplication] presentLocalNotificationNow:alarm];
}

@end
