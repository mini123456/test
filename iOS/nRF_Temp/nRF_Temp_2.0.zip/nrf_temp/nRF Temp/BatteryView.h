//
//  BatteryLabel.h
//  MasterDetailContainerTest
//
//  Created by Ole Morten on 9/11/13.
//  Copyright (c) 2013 Nordic Semiconductor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BatteryView : UIView
- (void) setBatteryLevel:(NSNumber *)level;
@end
