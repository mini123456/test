//
//  FobViewController.h
//  nRF Temp
//
//  Created by Ole Morten on 10/16/12.
//
//

#import <UIKit/UIKit.h>

#import "TemperatureFob.h"
#import "BatteryView.h"

@interface FobViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, TemperatureFobDelegate>
@property (strong, nonatomic) TemperatureFob *fob;

@property (weak, nonatomic) IBOutlet UILabel *idLabel;
@property (weak, nonatomic) IBOutlet UITextField *locationField;
@property (weak, nonatomic) IBOutlet BatteryView *batteryView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (weak, nonatomic) IBOutlet UIImageView *signalStrengthImage;

- (void) setFob:(TemperatureFob *)fob;
- (IBAction) nameChanged:(id)sender;

@end
