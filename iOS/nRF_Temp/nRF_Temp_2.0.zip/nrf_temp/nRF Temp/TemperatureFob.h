//
//  TemperatureFob.h
//  nRF Temp
//
//  Created by Ole Morten on 10/18/12.
//
//

#import <Foundation/Foundation.h>

#import "TemperatureReading.h"

@protocol TemperatureFobDelegate
- (void) didUpdateData:(TemperatureFob *) fob;
@end

@interface TemperatureFob : NSManagedObject
@property (nonatomic, retain) id<TemperatureFobDelegate> delegate;

@property (nonatomic, retain) NSNumber *batteryLevel;
@property (nonatomic, retain) NSNumber *temperature;
@property (nonatomic, retain) NSString *idString;
@property (assign) BOOL isSaved;
@property (nonatomic, retain) NSString *location;
@property (nonatomic, retain) NSNumber *signalStrength;
@property (nonatomic, retain) NSSet *readings;

+ (CBUUID *) batteryServiceUUID;
+ (CBUUID *) thermometerServiceUUID;

+ (TemperatureFob *) fobWithId:(NSString *) idString;
+ (TemperatureFob *) createFobWithId:(NSString *) idString;

+ (NSArray *) allStoredFobs;
+ (NSArray *) allFoundFobs;

+ (void) deleteFoundFobs;
+ (BOOL) deleteFob:(TemperatureFob *) fob;

- (UIImage *) currentSignalStrengthImage;
- (void) setBatteryLevelWithRawData:(NSData *) rawData;
- (BOOL) addReadingWithRawData:(NSData *)rawData;

- (TemperatureReading *) lastReading;
- (NSArray *) lastReadings:(NSUInteger) number;
- (NSArray *) lastReadingsSince:(NSUInteger) minutes;
@end

@interface TemperatureFob (CoreDataGeneratedAccessors)

- (void)addReadingsObject:(NSManagedObject *)value;
- (void)removeReadingsObject:(NSManagedObject *)value;
- (void)addReadings:(NSSet *)values;
- (void)removeReadings:(NSSet *)values;

@end
