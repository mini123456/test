//
//  TemperatureFob.m
//  nRF Temp
//
//  Created by Ole Morten on 10/18/12.
//
//

#import "TemperatureFob.h"

#import "AppDelegate.h"

@implementation TemperatureFob

@dynamic batteryLevel;
@dynamic idString;
@dynamic isSaved;
@dynamic location;
@dynamic readings;
@dynamic temperature;

@synthesize signalStrength = _signalStrength;

@synthesize delegate = _delegate;

+ (CBUUID *) batteryServiceUUID
{
    return [CBUUID UUIDWithString:@"180F"];
}

+ (CBUUID *) thermometerServiceUUID
{
    return [CBUUID UUIDWithString:@"1809"];
}

+ (TemperatureFob *) fobWithId:(NSString *) idString
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TemperatureFob"];
    [request setPredicate:[NSPredicate predicateWithFormat:@"idString LIKE %@", idString]];
    
    NSManagedObjectContext *moc = [(AppDelegate*) [[UIApplication sharedApplication] delegate] managedObjectContext];
    NSError *error;
    NSArray *array = [moc executeFetchRequest:request error:&error];
    
    if ([array count] == 1)
    {
        return [array objectAtIndex:0];
    }
    else if (error)
    {
        NSLog(@"Fetching failed. Error: %@. Count: %d.", error, [array count]);
    }
    return nil;
}

+ (TemperatureFob *) createFobWithId:(NSString *) idString
{
    NSManagedObjectContext *managedObjectContext = [(AppDelegate*) [[UIApplication sharedApplication] delegate] managedObjectContext];
    
    TemperatureFob *fob = (TemperatureFob *) [NSEntityDescription insertNewObjectForEntityForName:@"TemperatureFob" inManagedObjectContext:managedObjectContext];
    fob.idString = idString;
    fob.isSaved = NO;
    
    // Set default name and location to known value.
    fob.location = @"nRF Temp";
    return fob;
}

+ (NSArray *) allStoredFobs
{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    
    NSError *error;
    NSArray *array = [delegate.managedObjectContext executeFetchRequest:[delegate.managedObjectModel fetchRequestTemplateForName:@"StoredFobs"] error:&error];
    if (error)
    {
        NSLog(@"Fetching stored fobs failed. Error: %@", error);
    }
    return array;
    
}

+ (NSArray *) allFoundFobs
{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    NSError *error;
    
    NSArray *array = [delegate.managedObjectContext executeFetchRequest:[delegate.managedObjectModel fetchRequestTemplateForName:@"FoundFobs"] error:&error];
    if (error)
    {
        NSLog(@"Fetching found fobs failed. Error: %@", error);
    }
    return array;
}

+ (void) deleteFoundFobs
{
    for (TemperatureFob *f in self.allFoundFobs)
    {
        [self deleteFob:f];
    }
}

+ (BOOL) deleteFob:(TemperatureFob *) fob
{
    NSManagedObjectContext *moc = [(AppDelegate*) [[UIApplication sharedApplication] delegate] managedObjectContext];
    
    [moc deleteObject:fob];
    
    NSError *error;
    [moc save:&error];
    if (error)
    {
        NSLog(@"Error deleting fob: %@", error);
        return false;
    }
    else
    {
        return true;
    }
}

- (void) setBatteryLevelWithRawData:(NSData *)rawData
{
    uint8_t value;
    [rawData getBytes:&value length:1];
    self.batteryLevel = [NSNumber numberWithUnsignedShort:value];
    
    [self.delegate didUpdateData:self];
}

- (BOOL) addReadingWithRawData:(NSData *)rawData
{
    NSDate *now = [NSDate date];
    
    if ([now timeIntervalSinceDate:[self.lastReading date]] < 60.0)
    {
        return false;
    }
    
    TemperatureReading *reading = (TemperatureReading *) [NSEntityDescription insertNewObjectForEntityForName:@"TemperatureReading" inManagedObjectContext:self.managedObjectContext];
    
    [reading setDate:[NSDate date]];
    [reading setRawValue:rawData];
    
    [self addReadingsObject:reading];
    
    [self.delegate didUpdateData:self];
    
    return true;
}

- (UIImage *) currentSignalStrengthImage
{
    NSString *imageName;
    if (self.signalStrength.floatValue > -40.0)
        imageName = @"3-BARS.png";
    else if (self.signalStrength.floatValue > -60.0)
        imageName = @"2-BARS.png";
    else if (self.signalStrength.floatValue > -100.0)
        imageName = @"1-BAR.png";
    else
        imageName = @"0-BARS.png";
    
    return [UIImage imageNamed:imageName];
}

- (TemperatureReading *) lastReading
{
    NSArray *readings = [self lastReadings:0];
    if ([readings count] > 0)
    {
        return [readings objectAtIndex:0];
    }
    else
    {
        return nil;
    }
}

- (NSArray *) lastReadings:(NSUInteger) number
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TemperatureReading"];
    [request setFetchLimit:number];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    [request setPredicate:[NSPredicate predicateWithFormat:@"fob.idString LIKE %@", self.idString]];
    NSError *error;
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:&error];
    if (error)
    {
        NSLog(@"Fetching readings failed: %@", error);
    }
    return array;
}

- (NSArray *) lastReadingsSince:(NSUInteger) minutes
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TemperatureReading"];
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSDate *startTime = [NSDate dateWithTimeIntervalSinceNow:-(minutes*60.0)];
    [request setPredicate:[NSPredicate predicateWithFormat:@"fob.idString LIKE %@ AND date >= %@", self.idString, startTime]];
    NSError *error;
    NSArray *array = [self.managedObjectContext executeFetchRequest:request error:&error];
    if (error)
    {
        NSLog(@"Fetching readings failed: %@", error);
    }
    return array;
    
}
                                   

@end
