//
//  ScanForViewController.h
//  MyBluetooth
//
//  Created by s on 14-3-4.
//  Copyright (c) 2014年 sunward. All rights reserved.
//

#import "ViewController.h"

@interface ScanForViewController : ViewController


-(IBAction) reScan:(id)Sender;

@end
